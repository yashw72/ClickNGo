
import 'package:clickngo/ADScreen.dart';
import 'package:clickngo/push_not.dart';

import 'package:clickngo/controller.dart';
import 'package:clickngo/screens/splash_screen.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:googleapis/airquality/v1.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:pusher_beams/pusher_beams.dart';

import 'HOD/map.dart';
import 'HOD/root3.dart';
import 'Users/register.dart';
import 'ad.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();  // Initialize AdMob SDK
  await Firebase.initializeApp();
  await Supabase.initialize(
    url: 'https://wnhbujlqgzlxxtppailp.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InduaGJ1amxxZ3pseHh0cHBhaWxwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjY4MTMzOTMsImV4cCI6MjA0MjM4OTM5M30.jdXzcKZD8JKNNtClRZgH2Gh6dOwOhKtuzomRpxtRcao',
  );
  Get.put(InternetController(), permanent: true);

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();

  const AndroidInitializationSettings initializationSettingsAndroid =
  AndroidInitializationSettings('@mipmap/ic_launcher');

  final InitializationSettings initializationSettings =
  InitializationSettings(android: initializationSettingsAndroid);

  await flutterLocalNotificationsPlugin.initialize(initializationSettings);

  runApp(MyApp(flutterLocalNotificationsPlugin));
}

class MyApp extends StatelessWidget {
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

  const MyApp(this.flutterLocalNotificationsPlugin, {super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'ClickNGo',
      theme: ThemeData(
        fontFamily : 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home:SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }

}
