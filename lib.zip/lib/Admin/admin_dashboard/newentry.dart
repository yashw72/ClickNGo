import 'package:clickngo/Admin/admin_root_page.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../Component/color.dart';
import 'package:firebase_auth/firebase_auth.dart';


class NewEntry extends StatefulWidget {
  final String email;
  const NewEntry({super.key, required this.email});

  @override
  State<NewEntry> createState() => _NewEntryState();
}

class _NewEntryState extends State<NewEntry> {
  String? Orgname;
  String Orgemail = '';
  int? serialNumber;

  // Controllers for the input fields
  late TextEditingController _serialnumberController;
  late TextEditingController _organizationNameController;
  late TextEditingController _emailController;
  late TextEditingController _nameController;
  late TextEditingController _vehicleNumberController;
  late TextEditingController _purposeController;

  DateTime selectedDate = DateTime.now();
  TimeOfDay selectedTime = TimeOfDay.now();

  String get selectedDateTime {
    final int hours = selectedTime.hour;
    final int minutes = selectedTime.minute;

    final DateTime dateTime = DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      hours,
      minutes,
    );

    final DateFormat formatter = DateFormat('yyyy-MM-dd HH:mm:ss');
    return formatter.format(dateTime);
  }

  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    _serialnumberController = TextEditingController();
    _nameController = TextEditingController();
    _vehicleNumberController = TextEditingController();
    _emailController = TextEditingController();
    _organizationNameController = TextEditingController();
    _purposeController = TextEditingController();
    getOrgNameByEmail();
    fetchSerialNumber(); // Fetch the serial number on form load
  }

  Future<void> getOrgNameByEmail() async {
    try {
      User? admin = _auth.currentUser;
      if (admin != null) {
        Orgemail = admin.email!;
        DocumentSnapshot<Map<String, dynamic>> snapshot = await FirebaseFirestore.instance
            .collection('Organizations')
            .doc(Orgemail)
            .get();

        if (snapshot.exists) {
          Orgname = snapshot.data()?['Org Name'];
          _organizationNameController.text = Orgname!;
        } else {
          print('No organization found for this email.');
        }
        print(Orgname);
        print(Orgemail);
      }
    } catch (e) {
      print('Error retrieving organization name: $e');
    }
  }

  // Fetch the next serial number
  Future<void> fetchSerialNumber() async {
    try {
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('Organizations')
          .doc(Orgemail)
          .collection('DATA')
          .get();

      int entryCount = snapshot.docs.length;
      serialNumber = entryCount + 1; // Increment to get the next serial number
      _serialnumberController.text = serialNumber.toString(); // Display in the Entry No field
    } catch (e) {
      print('Error fetching serial number: $e');
    }
  }

  Future<void> _submitFormData() async {
    try {
      if (Orgname != null && Orgname!.isNotEmpty && serialNumber != null) {
        final firestore = FirebaseFirestore.instance;

        // Store in Users collection
        final orgDataDocRef = firestore
            .collection('Users')
            .doc(_emailController.text)
            .collection('History')
            .doc();

        await orgDataDocRef.set({
          'Name': _nameController.text,
          'VehicleNumber': _vehicleNumberController.text,
          'Email': _emailController.text,
          'Organization': Orgname,
          'Purpose': _purposeController.text,
          'DateTime': selectedDateTime,
        });

        // Store in Organizations collection with serial number as document ID
        final dataCollectionsRef = firestore
            .collection('Organizations')
            .doc(Orgemail)
            .collection('DATA');

        await dataCollectionsRef.doc().set({
          'EntryNo': serialNumber,
          'Name': _nameController.text,
          'VehicleNumber': _vehicleNumberController.text,
          'Email': _emailController.text,
          'Organization': Orgname,
          'Purpose': _purposeController.text,
          'DateTime': selectedDateTime,
        });

        // Re-sequence entries based on DateTime
        await _reSequenceEntryNumbers();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Form Submitted Successfully'),
            backgroundColor: Colors.green,
          ),
        );

        // Navigate to AdminRootPage
        Future.delayed(Duration(milliseconds: 500), () {
          Get.off(() => AdminRootPage(email: Orgemail));
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: Organization name or serial number is null or empty'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error submitting form: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _checkFormAndSubmit() {
    if (_purposeController.text.isNotEmpty) {
      _submitFormData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please fill out the Purpose of Visit.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );
    if (picked != null && picked != selectedTime) {
      setState(() {
        selectedTime = picked;
      });
    }
  }

  Future<void> _reSequenceEntryNumbers() async {
    try {
      final firestore = FirebaseFirestore.instance;

      // Fetch all entries and order by DateTime
      final snapshot = await firestore
          .collection('Organizations')
          .doc(Orgemail)
          .collection('DATA')
          .orderBy('DateTime')
          .get();

      final documents = snapshot.docs;

      // Re-sequence entries
      for (int i = 0; i < documents.length; i++) {
        await documents[i].reference.update({
          'EntryNo': i + 1, // Re-sequence starting from 1
        });
      }
    } catch (e) {
      print('Error re-sequencing entry numbers: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error re-sequencing entry numbers'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

    @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("New Entry"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTextFormField('Entry No:', _serialnumberController, readOnly: true),
              _buildTextFormField('Organization Name:', _organizationNameController),
              _buildTextFormField('Email:', _emailController),
              _buildTextFormField('Name:', _nameController),
              _buildTextFormField('Vehicle Number:', _vehicleNumberController),
              Text(
                'Date and Time:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _selectDate(context),
                      child: Text("${selectedDate.toLocal()}".split(' ')[0]),
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _selectTime(context),
                      child: Text("${selectedTime.format(context)}"),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              _buildTextFormField('Purpose of Visit:', _purposeController),
              SizedBox(height: 24),
              Center(
                child: ElevatedButton(
                  onPressed: _checkFormAndSubmit,
                  child: Text('Submit'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextFormField(String label, TextEditingController controller, {bool readOnly = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 8),
        TextFormField(
          controller: controller,
          readOnly: readOnly,
          decoration: InputDecoration(
            border: OutlineInputBorder(),
            labelText: label,
            labelStyle: TextStyle(color: Colors.black54),
          ),
        ),
        SizedBox(height: 16),
      ],
    );
  }
}
