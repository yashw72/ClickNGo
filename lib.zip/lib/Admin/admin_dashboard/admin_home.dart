import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:clickngo/Component/color.dart';

import '../../banner_ad_widget.dart';


class AdminHome extends StatefulWidget {
  final String email;
  const AdminHome({Key? key, required this.email}) : super(key: key);

  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  Stream<QuerySnapshot>? _adminhistoryStream;
  String? orgemail;
  String? orgname;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    _fetchAndInitializeStream();
  }

  Future<void> _fetchAndInitializeStream() async {
    User? admin = _auth.currentUser;
    if (admin != null) {
      orgemail = admin.email;
      final orgSnapshot = await _firestore
          .collection('Organizations')
          .where('Org Email', isEqualTo: widget.email)
          .get();

      if (orgSnapshot.docs.isNotEmpty) {
        orgname = orgSnapshot.docs.first.id;
        setState(() {
          _adminhistoryStream = _firestore
              .collection('Organizations')
              .doc(orgemail)
              .collection('DATA')
              .orderBy("EntryNo", descending: true)
              .snapshots();
        });
      } else {
        setState(() {
          _adminhistoryStream = null;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _adminhistoryStream == null
          ? Center(child: CircularProgressIndicator())
          : StreamBuilder<QuerySnapshot>(
        stream: _adminhistoryStream,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error fetching history: ${snapshot.error}',
                style: TextStyle(color: Colors.red, fontSize: 16),
              ),
            );
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Column(
              children: [
                // Replace this Container with your ad widget
                BannerAdWidget(),
                Spacer(), // Pushes the text to the center of the screen
                Center(
                  child: Text(
                    'No history available.',
                    style: TextStyle(color: Colors.black54, fontSize: 16),
                  ),
                ),
                Spacer(), // Optional: Add another Spacer for equal spacing if needed
              ],
            );
          }



          final historyDocs = snapshot.data!.docs;

          return Column(
            children: [
              BannerAdWidget(),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(16.0),
                  itemCount: historyDocs.length,
                  itemBuilder: (context, index) {
                    final doc = historyDocs[index];
                    final data = doc.data() as Map<String, dynamic>;

                    return Container(
                      margin: const EdgeInsets.only(bottom: 16.0),
                      padding: const EdgeInsets.all(16.0),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            spreadRadius: 1,
                            blurRadius: 8,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Stack(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Title and icons row
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Text(
                                      'Entry No: ${data['EntryNo']}',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: Colors.black87,
                                      ),
                                    ),
                                  ),
                                  GestureDetector(
                                    child: IconButton(
                                      icon: Icon(Icons.edit),
                                      onPressed: () {
                                        _showEditDialog(context, doc.id, data);
                                      },
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.delete),
                                    onPressed: () {
                                      // Handle delete action
                                      _confirmDeleteEntry(doc.id);
                                    },
                                  ),
                                ],
                              ),
                              // ExpansionTile
                              ExpansionTile(
                                title: Text('Details'),
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'User Name: ${data['Name']}',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black54,
                                          ),
                                        ),
                                        SizedBox(height: 8),
                                        Text(
                                          'Email: ${data['Email']}',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black54,
                                          ),
                                        ),
                                        SizedBox(height: 8),
                                        Text(
                                          'Date and Time: ${data['DateTime']}',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black54,
                                          ),
                                        ),
                                        SizedBox(height: 8),
                                        Text(
                                          'Vehicle No: ${data['VehicleNumber']}',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black54,
                                          ),
                                        ),
                                        SizedBox(height: 8),
                                        Text(
                                          'Purpose: ${data['Purpose']}',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black54,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  void _showEditDialog(BuildContext context, String docId,
      Map<String, dynamic> data) {
    TextEditingController entryNoController = TextEditingController(
        text: data['EntryNo'].toString());
    TextEditingController userNameController = TextEditingController(
        text: data['Name']);
    TextEditingController vehicleNumberController = TextEditingController(
        text: data['VehicleNumber']);
    TextEditingController emailController = TextEditingController(
        text: data['Email']);
    TextEditingController dateTimeController = TextEditingController(
        text: data['DateTime']);
    TextEditingController organizationController = TextEditingController(
        text: data['Organization']);
    TextEditingController purposeController = TextEditingController(
        text: data['Purpose']);

    Future<void> _selectDateTime(BuildContext context) async {
      DateTime? pickedDate = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2000),
        lastDate: DateTime(2101),
      );
      if (pickedDate != null) {
        TimeOfDay? pickedTime = await showTimePicker(
          context: context,
          initialTime: TimeOfDay.now(),
        );
        if (pickedTime != null) {
          DateTime finalDateTime = DateTime(
            pickedDate.year,
            pickedDate.month,
            pickedDate.day,
            pickedTime.hour,
            pickedTime.minute,
          );

          String formattedDateTime = "${finalDateTime.year}-${finalDateTime
              .month.toString().padLeft(2, '0')}-${finalDateTime.day.toString()
              .padLeft(2, '0')} ${finalDateTime.hour.toString().padLeft(
              2, '0')}:${finalDateTime.minute.toString().padLeft(2, '0')}:00";

          dateTimeController.text = formattedDateTime;
        }
      }
    }

    Future<void> _reSequenceEntryNumbers() async {
      final firestore = FirebaseFirestore.instance;

      try {
        final dataSnapshot = await firestore
            .collection('Organizations')
            .doc(widget.email)
            .collection('DATA')
            .orderBy('DateTime') // Order by DateTime field
            .get();

        final List<QueryDocumentSnapshot> documents = dataSnapshot.docs;

        for (int i = 0; i < documents.length; i++) {
          await documents[i].reference.update({
            'EntryNo': i + 1, // Re-sequence starting from 1
          });
        }
      } catch (e) {
        print('Error re-sequencing entry numbers: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error re-sequencing entry numbers'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
          ),
          elevation: 16,
          backgroundColor: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Edit Entry',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                    ),
                  ),
                  SizedBox(height: 16),
                  _buildTextField(
                      entryNoController, 'Entry No', Icons.confirmation_number),
                  _buildTextField(
                      userNameController, 'User Name', Icons.person),
                  _buildTextField(
                      vehicleNumberController, 'Vehicle No', Icons.car_rental),
                  _buildTextField(emailController, 'Email', Icons.email),
                  GestureDetector(
                    onTap: () async {
                      await _selectDateTime(context);
                    },
                    child: AbsorbPointer(
                      child: _buildTextField(dateTimeController, 'Date & Time',
                          Icons.calendar_today),
                    ),
                  ),
                  _buildTextField(
                      organizationController, 'Organization', Icons.business),
                  _buildTextField(
                      purposeController, 'Purpose of Visit', Icons.description),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildDialogButton(context, 'Cancel', Colors.red, () {
                        Navigator.of(context).pop();
                      }),
                      _buildDialogButton(
                          context, 'Save', Colors.green, () async {
                        try {
                          // Update entry
                          await FirebaseFirestore.instance
                              .collection('Organizations')
                              .doc(orgemail)
                              .collection('DATA')
                              .doc(docId)
                              .update({
                            'EntryNo': int.parse(entryNoController.text),
                            'Name': userNameController.text,
                            'VehicleNumber': vehicleNumberController.text,
                            'Email': emailController.text,
                            'DateTime': dateTimeController.text,
                            'Organization': organizationController.text,
                            'Purpose': purposeController.text,
                          });

                          // Re-sequence entries based on DateTime
                          await _reSequenceEntryNumbers();

                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(
                                'Entry updated and re-sequenced successfully'),
                              backgroundColor: Colors.green,
                            ),
                          );

                          Navigator.of(context).pop();
                        } catch (e) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Error updating entry: $e')),
                          );
                        }
                      }),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }



  Widget _buildTextField(TextEditingController controller, String label,
      IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: Colors.black54),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: BorderSide(color: primaryColor),
          ),
          labelStyle: TextStyle(color: primaryColor),
        ),
      ),
    );
  }

  Widget _buildDialogButton(BuildContext context, String label, Color color,
      VoidCallback onPressed) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        // Use backgroundColor instead of primary
        foregroundColor: Colors.white,
        // Use foregroundColor instead of onPrimary
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
      onPressed: onPressed,
      child: Text(label),
    );
  }

  void _confirmDeleteEntry(String docId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm Delete'),
          content: Text('Are you sure you want to delete this entry?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
                _deleteEntry(docId); // Call the delete function
              },
              child: Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  void _deleteEntry(String docId) async {
    try {
      // Delete the entry document from Firestore
      await FirebaseFirestore.instance
          .collection('Organizations')
          .doc(widget.email)
          .collection('DATA')
          .doc(docId)
          .delete();

      // Re-sequence the remaining entries after deletion
      await _reSequenceEntryNumbers();

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Entry deleted and re-sequenced successfully'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      print("Error deleting entry: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error deleting entry'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _reSequenceEntryNumbers() async {
    final firestore = FirebaseFirestore.instance;

    try {
      // Get all the remaining entries in the 'DATA' subcollection and order them by DateTime
      final dataSnapshot = await firestore
          .collection('Organizations')
          .doc(widget.email)
          .collection('DATA')
          .orderBy('DateTime') // Order by DateTime field
          .get();

      final List<QueryDocumentSnapshot> documents = dataSnapshot.docs;

      // Loop through the documents and re-sequence the EntryNo from 1 to n
      for (int i = 0; i < documents.length; i++) {
        await documents[i].reference.update({
          'EntryNo': i + 1, // Re-sequence starting from 1
        });
      }

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Entry numbers re-sequenced successfully'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      print('Error re-sequencing entry numbers: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error re-sequencing entry numbers'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}