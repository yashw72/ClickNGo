import 'dart:async';
import 'dart:convert';
import 'package:clickngo/FACULTY/Faculty-profile.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:http/http.dart' as http;

import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:clickngo/Users/Form.dart';
import 'package:clickngo/screens/Settings_page.dart';
import 'package:clickngo/screens/history_page.dart';
import 'package:clickngo/screens/home_page.dart';
import 'package:clickngo/screens/notification_page.dart';
import 'package:clickngo/screens/profile_page.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:background_location/background_location.dart' as bg_location;
import 'package:googleapis_auth/auth.dart';
import 'package:googleapis_auth/auth_io.dart';
import 'package:intl/intl.dart';
import 'package:location/location.dart' as loc;
import 'package:page_transition/page_transition.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:telephony/telephony.dart';
import 'package:uuid/uuid.dart';





class RootPage2 extends StatefulWidget {
  final String email;

  const RootPage2({Key? key, required this.email}) : super(key: key);

  @override
  State<RootPage2> createState() => _RootPage2State();
}

class _RootPage2State extends State<RootPage2> {
  int _bottomNavIndex = 0;
  final loc.Location location = loc.Location();
  String scanResult = '';
  double currentDistance = 0.0;
  String name="";
  String branch="";
  final Telephony telephony = Telephony.instance;
  List<Map<String, dynamic>> history = []; // List to store history

  // Define the title list for each bottom navigation tab
  final List<String> titleList = [
    'Home',
    'Notifications',
    'History',
    'Settings',
  ];

  // Define the icon list for each bottom navigation tab
  final List<IconData> iconList = [
    Icons.home,
    Icons.notifications,
    Icons.history,
    Icons.settings,
  ];

  // List of the pages
  List<Widget> pages = [];
  FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  String? _deviceToken;

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _getDeviceToken();
    _fetchDetails();
    _setupForegroundNotificationListener();
    _setupBackgroundNotificationListener();
    pages = [
      HomePage(distance: currentDistance,email: widget.email,),
      NotificationPage(),
      HistoryPage(email: widget.email),
      SettingsPage(),
    ];
  }

  // Get the device token from Firestore using hodemail
  void _getDeviceToken() async {
    try {
      // Get HOD email from branch
      await _fetchDetails();
      String? hodEmail = await getHODEmailFromBranch(branch);

      if (hodEmail != null) {

        // Replace 'HOD_Tokens' with the actual name of your collection where device tokens are stored
        final docRef = FirebaseFirestore.instance.collection('HOD').doc(hodEmail);
        final docSnapshot = await docRef.get();

        if (docSnapshot.exists) {
          final data = docSnapshot.data();
          if (data != null && data.containsKey('deviceToken')) {
            setState(() {
              _deviceToken = data['deviceToken'];
            });
            print("Device Token: $_deviceToken");
          } else {
            print("Device token not found in Firestore.");
          }
        } else {
          print("HOD document does not exist in Firestore.");
        }
      } else {
        print("HOD email is null.");
      }
    } catch (e) {
      print("Error retrieving device token: $e");
    }
  }

  Future<void> storeLocationInSupabase(String email, String location) async {
    final response = await Supabase.instance.client
        .from('faculty')
        .upsert({
      'email': email,
      'name': name,
      'location': location,
      'updated_at': DateTime.now().toIso8601String(), // ISO 8601 format

    });

    if (response.error != null) {
      print('Error storing location: ${response.error!.message}');
    } else {
      print('Location stored successfully');
    }
  }

// Function to periodically check if location services are enabled

  bool notificationSent = false;
  Future<void> _checkLocationServices() async {


    // Check if GPS is enabled
    bool isGpsEnabled = await location.serviceEnabled();

    if (!isGpsEnabled && notificationSent == false) {

      print("GPS is turned off");


      // Fetch faculty details (name, branch, etc.)
      await _fetchDetails();

      // Get HOD email based on branch
      String? hodEmail = await getHODEmailFromBranch(branch);

      if (hodEmail != null && notificationSent ==false) {
        // Get current timestamp and formatted date-time string
        Timestamp currentTimestamp = Timestamp.now();
        DateTime currentDateTime = currentTimestamp.toDate();
        String formattedDate = DateFormat('yyyy-MM-dd').format(currentDateTime);
        String formattedTime = DateFormat('HH:mm:ss').format(currentDateTime);

        // Save the boundary breach info in Firestore for the faculty's personal collection
        await FirebaseFirestore.instance
            .collection('HOD')
            .doc(hodEmail)
            .collection("faculties")
            .doc(name)
            .collection("BREACHES")
            .add({
          'facultyName': name,
          'facultyEmail': widget.email,
          'information': "GPS turned off",
          'dateCrossed': formattedDate,  // Save formatted date
          'timeCrossed': formattedTime,  // Save formatted time
        });

        // Save the boundary breach info in Firestore for the HOD's breaches collection
        await FirebaseFirestore.instance
            .collection('HOD')
            .doc(hodEmail)
            .collection("BREACHES")
            .add({
          'facultyName': name,
          'facultyEmail': widget.email,
          'information': "GPS turned off",
          'dateCrossed': formattedDate,  // Save formatted date
          'timeCrossed': formattedTime,  // Save formatted time
        });

        // Send push notification to HOD
        notificationSent=true;
        _sendPushNotification("GPS was turned off by $name on $formattedDate at $formattedTime.");
      }


    }
    if(isGpsEnabled==true){
      notificationSent = false;
    }

  }

  bool internetNotificationSent = false;
  String? breachData; // Variable to store a single breach
  String? hodEmail; // Declare hodEmail here

  Future<bool> _isInternetAvailable() async {
    var connectivityResult = await Connectivity().checkConnectivity();
    return connectivityResult != ConnectivityResult.none;
  }

// Function to send stored breach data to Firestore
  Future<void> _sendStoredBreach() async {
    if (breachData != null) {
      List<String> breachDetails = breachData!.split('|');
      String hodEmail = breachDetails[0];
      String name = breachDetails[1];
      String email = breachDetails[2];
      String formattedDate = breachDetails[3];
      String formattedTime = breachDetails[4];

      try {
        // Save the breach info in Firestore for the faculty's personal collection
        await FirebaseFirestore.instance
            .collection('HOD')
            .doc(hodEmail)
            .collection("faculties")
            .doc(name)
            .collection("BREACHES")
            .add({
          'facultyName': name,
          'facultyEmail': email,
          'information': "Internet was turned off",
          'dateCrossed': formattedDate,
          'timeCrossed': formattedTime,
        });

        // Save the breach info in Firestore for the HOD's breaches collection
        await FirebaseFirestore.instance
            .collection('HOD')
            .doc(hodEmail)
            .collection("BREACHES")
            .add({
          'facultyName': name,
          'facultyEmail': email,
          'information': "Internet was turned off",
          'dateCrossed': formattedDate,
          'timeCrossed': formattedTime,
        });

        // Clear the stored breach after sending
        breachData = null; // Resetting the breachData
      } catch (e) {
        print("Error sending breach data: $e");
      }
    }
  }
String dateTime = "";
  Future<void> _checkInternetConnectivity() async {
    bool internetAvailable = await _isInternetAvailable();

    if (internetAvailable) {
      // Fetch faculty details (name, branch, etc.)
      await _fetchDetails(); // Implement this function

      // Get HOD email based on branch
      hodEmail =
      await getHODEmailFromBranch(branch); // Assign to the outer variable
    }
    if (!internetAvailable && internetNotificationSent==false) {
      print("Internet turned off");

      if (hodEmail != null && internetNotificationSent==false) {
        // Get current timestamp and formatted date-time string
        Timestamp currentTimestamp = Timestamp.now();
        DateTime currentDateTime = currentTimestamp.toDate();
        String formattedDate = DateFormat('yyyy-MM-dd').format(currentDateTime);
        String formattedTime = DateFormat('HH:mm:ss').format(currentDateTime);
        dateTime = formattedDate + " : " + formattedTime;
        // Save breach information in the string variable
        breachData = '$hodEmail|$name|${widget.email}|$formattedDate|$formattedTime';
        print(breachData);
        internetNotificationSent = true; // Mark notification as sent
      }
    }

    if (internetAvailable) {
      // Send the stored breach to Firestore
      if (internetNotificationSent) {
        await _sendStoredBreach();
        internetNotificationSent =false;
        // Send notification to HOD for the incident
        _sendPushNotification("The internet was turned off by the faculty: $name at $dateTime ");
      }
      internetNotificationSent = false; // Reset notification status
    }
  }
  bool permissionnotificationSent = false;

  Future<void> _checkpermissions() async {
    final locationStatus = await Permission.locationWhenInUse.status;
    final notificationStatus = await Permission.notification.status;
    if ((!notificationStatus.isGranted  || !locationStatus.isGranted) && permissionnotificationSent==false) {

      print("Permissions were revoked");


      // Fetch faculty details (name, branch, etc.)
      await _fetchDetails();

      // Get HOD email based on branch
      String? hodEmail = await getHODEmailFromBranch(branch);

      if (hodEmail != null && permissionnotificationSent ==false) {
        // Get current timestamp and formatted date-time string
        Timestamp currentTimestamp = Timestamp.now();
        DateTime currentDateTime = currentTimestamp.toDate();
        String formattedDate = DateFormat('yyyy-MM-dd').format(currentDateTime);
        String formattedTime = DateFormat('HH:mm:ss').format(currentDateTime);

        // Save the boundary breach info in Firestore for the faculty's personal collection
        await FirebaseFirestore.instance
            .collection('HOD')
            .doc(hodEmail)
            .collection("faculties")
            .doc(name)
            .collection("BREACHES")
            .add({
          'facultyName': name,
          'facultyEmail': widget.email,
          'information': "Permissions were revoked",
          'dateCrossed': formattedDate,  // Save formatted date
          'timeCrossed': formattedTime,  // Save formatted time
        });

        // Save the boundary breach info in Firestore for the HOD's breaches collection
        await FirebaseFirestore.instance
            .collection('HOD')
            .doc(hodEmail)
            .collection("BREACHES")
            .add({
          'facultyName': name,
          'facultyEmail': widget.email,
          'information': "Permissions were revoked ",
          'dateCrossed': formattedDate,  // Save formatted date
          'timeCrossed': formattedTime,  // Save formatted time
        });

        // Send push notification to HOD
        permissionnotificationSent=true;
        _sendPushNotification("Permissions were revoked by $name on $formattedDate at $formattedTime.");
      }


    }
    if(locationStatus.isGranted==true){
      permissionnotificationSent = false;
    }

  }

// Function to start the location service check
  void _startLocationServiceCheck() {
    Timer.periodic(Duration(seconds: 1), (timer) async {
      await _checkLocationServices();
      await _checkInternetConnectivity();
      await _checkpermissions();
      // If location services are disabled, you can stop the timer or log the breach
    });
  }

  // Listen for foreground notifications
  void _setupForegroundNotificationListener() {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print('Got a message whilst in the foreground!');
      print('Message data: ${message.data}');

      if (message.notification != null) {
        print('Message also contained a notification: ${message.notification}');
        _showForegroundNotification(
            message.notification!.title,
            message.notification!.body
        );
      }
    });
  }

  // Listen for background and terminated state notifications
  void _setupBackgroundNotificationListener() {
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('Message clicked!');
      print('Message data: ${message.data}');
      // Handle navigation or other actions here
    });

    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  }

  // Background message handler
  Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
    print('Handling a background message: ${message.messageId}');
    if (message.notification != null) {
      print('Message also contained a notification: ${message.notification}');
    }
  }

  // Display notification manually when app is in the foreground
  void _showForegroundNotification(String? title, String? body) {
    if (title == null || body == null) return;

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(title),
          content: Text(body),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<String> _getAccessToken() async {
    final jsonString = await rootBundle.loadString('assets/clickngo-17114-f2ca1e6f62bd.json');
    var serviceAccountCredentials = ServiceAccountCredentials.fromJson(json.decode(jsonString));

    var scopes = ['https://www.googleapis.com/auth/firebase.messaging'];
    var client = http.Client();

    var accessCredentials = await obtainAccessCredentialsViaServiceAccount(
      serviceAccountCredentials,
      scopes,
      client,
    );
    return accessCredentials.accessToken.data;
  }

  // Function to send push notification
  void _sendPushNotification(String message) async {
    if (_deviceToken == null) {
      print("Device token is not available.");
      return;
    }

    String accessToken = await _getAccessToken();
    String fcmUrl = "https://fcm.googleapis.com/v1/projects/clickngo-17114/messages:send";

    Map<String, dynamic> notificationPayload = {
      "message": {
        "token": _deviceToken,
        "notification": {
          "title": "Breach caused!",
          "body": message,
        },
        "data": {
          "click_action": "FLUTTER_NOTIFICATION_CLICK",
          "status": "done"
        },
        "android": {
          "priority": "high"  // Set priority to high for Android
        }
      }
    };


    var response = await http.post(
      Uri.parse(fcmUrl),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $accessToken',
      },
      body: jsonEncode(notificationPayload),
    );

    if (response.statusCode == 200) {
      print("Push notification sent successfully.");
    } else {
      print("Failed to send push notification. Error: ${response.body}");
    }
  }
  // Function to validate UUID
  bool isValidUUID(String uuid) {
    try {
      Uuid.parse(uuid);
      return true;
    } catch (e) {
      return false;
    }
  }

  // Function to start scanning
  Future<void> startScan() async {
    var result;
    try {
      result = await FlutterBarcodeScanner.scanBarcode(
        '#00FF00',
        'Cancel',
        true,
        ScanMode.QR,
      );
      print("Scan result: $result"); // Log scan result
    } on PlatformException catch (e) {
      print("PlatformException: ${e.message}"); // Log exception
      Get.snackbar("Error Occurred", e.message ?? "Unknown error");
      return;
    } catch (e) {
      print("Exception: $e"); // Log exception
      Get.snackbar("Error", "An unexpected error occurred");
      return;
    }

    if (!mounted) return;

    if (result != '-1') {
      const String expectedPrefix = "https://66cb1c3dccec5e00083c8861--clickngoform.netlify.app/?organization=";

      if (result.startsWith(expectedPrefix)) {
        Uri uri = Uri.parse(result);
        String? orgUUID = uri.queryParameters['organizationid'];
        String? orgName = uri.queryParameters['organization'];

        if (orgUUID != null && isValidUUID(orgUUID)) {
          setState(() {
            scanResult = result;
          });

          Navigator.push(
            context,
            PageTransition(
              type: PageTransitionType.bottomToTop,
              child: MyFormPage(
                email: widget.email,
                orgName: orgName ?? '',
                orgUUID: orgUUID,
                onFormSubmitted: (entry) {
                  setState(() {
                    history.add(entry); // Append new entry
                  });
                },
              ),
            ),
          );
        } else {
          Get.snackbar(
            "Invalid QR Code",
            "The QR code does not contain a valid UUID.",
            backgroundColor: Colors.red,
            colorText: Colors.white,
          );
        }
      } else {
        Get.snackbar(
          "Invalid QR Code",
          "The scanned QR code does not have the correct prefix.",
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      }
    }
  }
  Future<void> _fetchDetails() async {
    try {
      final firestore = FirebaseFirestore.instance;
      final docRef = firestore.collection('Users').doc(widget.email);
      final docSnapshot = await docRef.get();

      if (docSnapshot.exists) {
        final data = docSnapshot.data()!;
        setState(() {
          name = data['Name'] ?? '';
          branch = data['Branch'] ?? '';
          print("Name retrieved : "+name);
          print("branch retrieved : "+branch);
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No user found with the provided email.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error fetching user details: $e')),
      );
    }
  }


  Future<void> _requestPermissions() async {
    // Request notification permission
    final notificationStatus = await Permission.notification.status;
    if (!notificationStatus.isGranted) {
      final notificationResult = await Permission.notification.request();
      if (!notificationResult.isGranted) {
        print('Notification permission denied');

        // Get current timestamp and formatted date-time string
        Timestamp currentTimestamp = Timestamp.now();
        DateTime currentDateTime = currentTimestamp.toDate();
        String formattedDate = DateFormat('yyyy-MM-dd').format(currentDateTime);
        String formattedTime = DateFormat('HH:mm:ss').format(currentDateTime);

        await _fetchDetails();

        String? hodemail = await getHODEmailFromBranch(branch);

        // Save the boundary breach info in Firestore for the faculty's personal collection
        await FirebaseFirestore.instance
            .collection('HOD')
            .doc(hodemail)
            .collection("faculties")
            .doc(name)
            .collection("BREACHES")
            .add({
          'facultyName': name,
          'facultyEmail': widget.email,
          'information' : "Notification permission denied",
          'dateCrossed': formattedDate,  // Save formatted date
          'timeCrossed': formattedTime,  // Save formatted time
        });

        // Save the boundary breach info in Firestore for the HOD's breaches collection
        await FirebaseFirestore.instance
            .collection('HOD')
            .doc(hodemail)
            .collection("BREACHES")
            .add({
          'facultyName': name,
          'facultyEmail': widget.email,
          'information' : "Notification permission denied",
          'dateCrossed': formattedDate,  // Save formatted date
          'timeCrossed': formattedTime,  // Save formatted time
        });
        _sendPushNotification("Notification permission was denied by the faculty: $name");
         // Exit if permission is denied
      }
    }

    // Request location permission
    final locationStatus = await Permission.locationWhenInUse.status;
    if (!locationStatus.isGranted) {

      final locationResult = await Permission.locationWhenInUse.request();
      if (!locationResult.isGranted) {
        print('Location permission denied');

        // Get current timestamp and formatted date-time string
        Timestamp currentTimestamp = Timestamp.now();
        DateTime currentDateTime = currentTimestamp.toDate();
        String formattedDate = DateFormat('yyyy-MM-dd').format(currentDateTime);
        String formattedTime = DateFormat('HH:mm:ss').format(currentDateTime);

        await _fetchDetails();

        String? hodemail = await getHODEmailFromBranch(branch);

        // Save the boundary breach info in Firestore for the faculty's personal collection
        await FirebaseFirestore.instance
            .collection('HOD')
            .doc(hodemail)
            .collection("faculties")
            .doc(name)
            .collection("BREACHES")
            .add({
          'facultyName': name,
          'facultyEmail': widget.email,
          'information' : "Location permission denied",
          'dateCrossed': formattedDate,  // Save formatted date
          'timeCrossed': formattedTime,  // Save formatted time
        });

        // Save the boundary breach info in Firestore for the HOD's breaches collection
        await FirebaseFirestore.instance
            .collection('HOD')
            .doc(hodemail)
            .collection("BREACHES")
            .add({
          'facultyName': name,
          'facultyEmail': widget.email,
          'information' : "Location permission denied",
          'dateCrossed': formattedDate,  // Save formatted date
          'timeCrossed': formattedTime,  // Save formatted time
        });
        _sendPushNotification("Location permission was denied by the faculty");
        return; // Exit if permission is denied
      }
    }
    if(locationStatus.isGranted && notificationStatus.isGranted) {
      _startLocationServiceCheck();
    }
    // Start tracking if permissions are granted
    startTracking();
    startBackgroundTracking(); // Start background tracking
  }

  // Function to start tracking location
  void startTracking() async {


    location.onLocationChanged.listen((loc.LocationData currentLocation) {
      // Log location update
      setState(() {

        currentDistance = _calculateDistance(currentLocation);
      });
      String email = widget.email; // Assuming you have the email here
      String location = '${currentLocation.latitude},${currentLocation.longitude}';
      storeLocationInSupabase(email, location); // Store the location
      checkGeofence(currentLocation);
    });
  }

  // Function to start background tracking
  void startBackgroundTracking() async {
    try {
      // Set up Android notification for background tracking
      await bg_location.BackgroundLocation.setAndroidNotification(
        title: 'Location Tracking',
        message: 'Your location is being tracked in the background',
        icon: '@mipmap/ic_launcher',
      );
      print("Android notification set up for background tracking");

      // Stop any previous location service if running
      await bg_location.BackgroundLocation.stopLocationService();
      print("Previous location service stopped");

      // Configure the background location settings and start the location service
      await bg_location.BackgroundLocation.setAndroidConfiguration(30000); // 30 seconds
      print("Background location configuration set");

      await bg_location.BackgroundLocation.startLocationService(distanceFilter: 10);
      print("Background location service started");

      // Start receiving location updates
      bg_location.BackgroundLocation.getLocationUpdates((bg_location.Location location) {
        print("Background location update: ${location.latitude}, ${location.longitude}"); // Log background location update
        setState(() {
          currentDistance = _calculateDistance(loc.LocationData.fromMap({
            'latitude': location.latitude,
            'longitude': location.longitude,
          }));
        });
        checkGeofence(loc.LocationData.fromMap({
          'latitude': location.latitude,
          'longitude': location.longitude,
        }));
      });
    } catch (e) {
      print("Error in background tracking: $e"); // Log any errors
    }
  }

  // Function to calculate distance
  double _calculateDistance(loc.LocationData currentLocation) {
    double collegeLat = 19.952975;
    double collegeLong = 73.863793;

    return Geolocator.distanceBetween(
      collegeLat,
      collegeLong,
      currentLocation.latitude!,
      currentLocation.longitude!,
    );
  }
  bool hasCrossedBoundary = false;
  // Function to check geofence
  // Function to check geofence
  Future<String?> getHODEmailFromBranch(String branch) async {
    try {
      final firestore = FirebaseFirestore.instance;
      final collection = firestore.collection('HOD');

      // Query documents where the 'Branch' field matches the given branch
      final querySnapshot = await collection.where('Branch', isEqualTo: branch).get();

      if (querySnapshot.docs.isNotEmpty) {
        // Assuming there is only one document per branch
        // Return the document ID which is the HOD email
        return querySnapshot.docs.first.id;
      } else {
        print('No HOD found for the branch: $branch');
        return null;
      }
    } catch (e) {
      print('Error fetching HOD email: $e');
      return null;
    }
  }
  Future<void> checkGeofence(loc.LocationData currentLocation) async {
    double collegeLat = 19.952975;
    double collegeLong = 73.863793;
    double boundaryRadius = 50;

    double distance = _calculateDistance(currentLocation);

    // Continuously send SMS if out of boundary
    if (distance > boundaryRadius && !hasCrossedBoundary) {
      setState(() {
        hasCrossedBoundary = true; // Set the flag to true when the boundary is crossed
      });

      // Get current timestamp and formatted date-time string
      Timestamp currentTimestamp = Timestamp.now();
      DateTime currentDateTime = currentTimestamp.toDate();
      String formattedDate = DateFormat('yyyy-MM-dd').format(currentDateTime);
      String formattedTime = DateFormat('HH:mm:ss').format(currentDateTime);

      await _fetchDetails();

      String? hodemail = await getHODEmailFromBranch(branch);

      // Save the boundary breach info in Firestore for the faculty's personal collection
      await FirebaseFirestore.instance
          .collection('HOD')
          .doc(hodemail)
          .collection("faculties")
          .doc(name)
          .collection("BREACHES")
          .add({
        'facultyName': name,
        'facultyEmail': widget.email,
        'information' : "Crossed Boundary",
        'dateCrossed': formattedDate,  // Save formatted date
        'timeCrossed': formattedTime,  // Save formatted time
      });

      // Save the boundary breach info in Firestore for the HOD's breaches collection
      await FirebaseFirestore.instance
          .collection('HOD')
          .doc(hodemail)
          .collection("BREACHES")
          .add({
        'facultyName': name,
        'facultyEmail': widget.email,
        'information' : "Crossed Boundary",
        'dateCrossed': formattedDate,  // Save formatted date
        'timeCrossed': formattedTime,  // Save formatted time
      });
      _sendPushNotification("$name has crossed the boundary!");
      // Notify user and send SMS
      _sendSmsNotification();
      Get.snackbar(
        "Boundary Alert",
        "You have crossed the college boundary!",
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.TOP,
        margin: EdgeInsets.all(8),
        borderRadius: 8,
        duration: Duration(seconds: 5),
      );
    } else if (distance <= boundaryRadius && hasCrossedBoundary) {
      setState(() {
        hasCrossedBoundary = false;
      });
    }
  }


  // Function to send SMS notification
  void _sendSmsNotification() async {
    String message = "You have crossed the boundary";
    List<String> recipients = [];

    for (String recipient in recipients) {
      try {
        await telephony.sendSms(
          to: recipient,
          message: message,
        );
        Get.snackbar("SMS Sent", "Notification SMS has been sent to $recipient.");

      } catch (e) {
        Get.snackbar("SMS Error", "Failed to send SMS to $recipient.");

      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              titleList[_bottomNavIndex],
              style: TextStyle(
                color: Colors.black54,
                fontWeight: FontWeight.w500,
                fontSize: 24,
              ),
            ),
            Container(
              child: GestureDetector(
                child: Icon(
                  Icons.person,
                  color: Colors.black54,
                  size: 30.0,
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    PageTransition(
                      type: PageTransitionType.rightToLeft,
                      child: ProfilePage2(),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0.0,
      ),
      body: IndexedStack(
        index: _bottomNavIndex,
        children: pages.map((page) {
          if (page is HomePage) {
            return HomePage(distance: currentDistance,email: widget.email,);
          }
          return page;
        }).toList(),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: startScan,
        child: Image.asset('assets/images/code-scan-two.png', height: 30.0),
        backgroundColor: Colors.black,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: AnimatedBottomNavigationBar(
        splashColor: Colors.black,
        activeColor: Colors.black,
        inactiveColor: Colors.black.withOpacity(.5),
        icons: iconList,
        activeIndex: _bottomNavIndex,
        gapLocation: GapLocation.center,
        notchSmoothness: NotchSmoothness.softEdge,
        onTap: (index) {
          setState(() {
            _bottomNavIndex = index;
          });
        },
      ),
    );
  }
}
