import 'package:clickngo/FACULTY/root2.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:lottie/lottie.dart';  // Import Lottie package
import 'dart:developer';
class DataScreen2 extends StatefulWidget {
  final String email;

  DataScreen2({super.key, required this.email});

  @override
  State<DataScreen2> createState() => _DataScreen2State();
}

class _DataScreen2State extends State<DataScreen2> {
  final TextEditingController nametc = TextEditingController();
  final TextEditingController rolltc = TextEditingController();
  final TextEditingController vehtc = TextEditingController();
  String? selectedBranch;
  final _formKey = GlobalKey<FormState>();

  String? phoneNumber;
  final List<String> branches = [
    "Computer Tech",
    "Civil",
    "Information Tech",
    "Mechanical",
    "Automobile",
    "Plastic",
    "E&TC",
    "Electrical",
    "IDD",
    "DDGM",
    "Mechatronics",
    "Science and humanity",
    "Workshop",
    "Applied Mechanics",
    "Other Dept"
  ];

  Future<String?> getHODEmailFromBranch(String branch) async {
    try {
      final firestore = FirebaseFirestore.instance;
      final collection = firestore.collection('HOD');

      final querySnapshot = await collection.where('Branch', isEqualTo: branch).get();

      if (querySnapshot.docs.isNotEmpty) {
        return querySnapshot.docs.first.id;
      } else {
        print('No HOD found for the branch: $branch');
        return null;
      }
    } catch (e) {
      print('Error fetching HOD email: $e');
      return null;
    }
  }

  Future<void> addData(String name, int no, String vehno, String branch, String phone) async {
    await FirebaseFirestore.instance.collection("Users").doc(widget.email).update({
      "Name": name,
      "Id": no,
      "Vehicle no": vehno.isNotEmpty ? vehno : "Not provided",
      "Branch": branch,
      "Phone": phone,
      "email": widget.email,
    }).then((value) {
      log("Data inserted");
    });

    String? hodEmail = await getHODEmailFromBranch(branch);
    await FirebaseFirestore.instance.collection("HOD").doc(hodEmail).collection("faculties").doc(name).update({
      "Name": name,
      "Id": no,
      "Vehicle no": vehno.isNotEmpty ? vehno : "Not provided",
      "Branch": branch,
      "Phone": phone,
      "email": widget.email,
    }).then((value) {
      log("Data inserted");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tell us a bit about yourself!"),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Container(
              constraints: BoxConstraints(maxWidth: 600),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SizedBox(height: 20),


                  Text(
                    "Enter your details",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: TextFormField(
                      controller: nametc,
                      decoration: InputDecoration(
                        hintText: "Enter your name",
                        suffixIcon: Icon(Icons.person),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Name is required';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: TextFormField(
                      controller: rolltc,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        hintText: "Enter your faculty number",
                        suffixIcon: Icon(Icons.numbers),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Faculty number is required';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: IntlPhoneField(
                      decoration: InputDecoration(
                        hintText: "Enter your phone number",
                        suffixIcon: Icon(Icons.phone),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      initialCountryCode: 'IN',
                      onChanged: (phone) {
                        phoneNumber = phone.completeNumber;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: TextFormField(
                      controller: vehtc,
                      decoration: InputDecoration(
                        hintText: "Enter your vehicle number (Optional)",
                        suffixIcon: Icon(Icons.directions_car),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: DropdownButtonFormField<String>(
                      value: selectedBranch,
                      decoration: InputDecoration(
                        hintText: "Select your branch",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      items: branches.map((String branch) {
                        return DropdownMenuItem<String>(
                          value: branch,
                          child: Text(branch),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedBranch = newValue;
                        });
                      },
                      validator: (value) {
                        if (value == null) {
                          return 'Branch is required';
                        }
                        return null;
                      },
                    ),
                  ),
                  SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        if (phoneNumber == null || phoneNumber!.isEmpty) {
                          // Show a dialog if the phone number is not entered
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: Text('Error'),
                                content: Text('Phone number is a required field.'),
                                actions: <Widget>[
                                  TextButton(
                                    child: Text('OK'),
                                    onPressed: () {
                                      Navigator.of(context).pop(); // Close the dialog
                                    },
                                  ),
                                ],
                              );
                            },
                          );
                        } else {
                          // Proceed with the existing functionality
                          if (nametc.text.isNotEmpty &&
                              rolltc.text.isNotEmpty &&
                              selectedBranch != null &&
                              phoneNumber!.isNotEmpty) {
                            addData(
                              nametc.text,
                              int.tryParse(rolltc.text) ?? 0,
                              vehtc.text,
                              selectedBranch ?? "",
                              phoneNumber!,
                            );
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => RootPage2(email: widget.email),
                              ),
                            );
                          }
                        }
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      padding: EdgeInsets.symmetric(
                        horizontal: 50,
                        vertical: 15,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Text(
                      "Submit",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}