import 'package:clickngo/Component/color.dart';
import 'package:clickngo/Onboboarding/onboarding_items.dart';
import 'package:clickngo/Users/root_page.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';


import '../UPDATES/update_checker.dart';
import '../Users/login_auth.dart';

class OnboardingView extends StatefulWidget {
  const OnboardingView({super.key});

  @override
  State<OnboardingView> createState() => _OnboardingViewState();
}

class _OnboardingViewState extends State<OnboardingView> {
  final controller = OnboardingItems();
  final pageController = PageController();
  UpdateChecker _updateChecker = UpdateChecker();
  bool isLastPage = false;
  @override
  void initState() {
    super.initState();
    _checkForUpdates();
  }
  // Check for app updates when the app starts
  void _checkForUpdates() async {
    await _updateChecker.checkForUpdate(context);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomSheet: Container(
        color: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        child: isLastPage? getStarted() : Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            //Skip Button
            TextButton(
                onPressed: () =>
                    pageController.jumpToPage(controller.items.length - 1),
                child: const Text("Skip")),

            //Indicator
            SmoothPageIndicator(
              controller: pageController,
              count: controller.items.length,
              onDotClicked: (index) => pageController.animateToPage(index,
                  duration: const Duration(milliseconds: 400), curve: Curves.easeIn),
              effect: const WormEffect(
                dotHeight: 12,
                dotWidth: 12,
                activeDotColor: primaryColor,
              ),
            ),

            //Next Button
            TextButton(
                onPressed: () => pageController.nextPage(
                    duration: Duration(milliseconds: 400),
                    curve: Curves.easeIn),
                child: const Text("Next")),
          ],
        ),
      ),
      body: Container(
        margin: const EdgeInsets.symmetric(horizontal: 25),
        child: PageView.builder(
            onPageChanged: (index)=> setState(()=>isLastPage = controller.items.length-1 == index),
            itemCount: controller.items.length,
            controller: pageController,
            itemBuilder: (context, index) {
              return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                        width:300,
                        height:200,
                        child: Image.asset(controller.items[index].image)
                    ),
                    const SizedBox(height: 20),
                    Text(
                      controller.items[index].title,
                      style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                    ),
                    // const SizedBox(height: 30),
                    Text(controller.items[index].descriptions,
                        style: TextStyle(color: Colors.grey, fontSize: 17),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                  ]);
            }),
      ),
    );
  }

  Widget getStarted(){
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: primaryColor,
      ),
      width: MediaQuery.of(context).size.width *.9,
      height: 55,
      child: TextButton(
          onPressed: ()async{
            final pres=  await SharedPreferences.getInstance();
            pres.setBool("onboarding", true);

            // After we press get started button this onboarding value gets True !!
            if(!mounted)return;
            Navigator.pushReplacement( context, MaterialPageRoute(builder: (context)=>EmailPasswordAuth()));
          },
          child: const Text("Get started",style: TextStyle(color: Colors.white),)),
    );
  }
}