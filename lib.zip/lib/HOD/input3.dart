import 'dart:developer';
import 'package:clickngo/FACULTY/root2.dart';
import 'package:clickngo/Users/root_page.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:lottie/lottie.dart'; // Import Lottie package

import 'root3.dart';

class DataScreen3 extends StatefulWidget {
  final String email;

  DataScreen3({super.key, required this.email});

  @override
  State<DataScreen3> createState() => _DataScreen3State();
}

class _DataScreen3State extends State<DataScreen3> {
  TextEditingController nametc = TextEditingController();
  TextEditingController rolltc = TextEditingController();
  TextEditingController vehtc = TextEditingController();
  String phoneNumber = "";
  String? selectedBranch;
  final _formKey = GlobalKey<FormState>();

  final List<String> branches = [
    "Computer Tech",
    "Civil",
    "Information Tech",
    "Mechanical",
    "Automobile",
    "Plastic",
    "E&TC",
    "Electrical",
    "IDD",
    "DDGM",
    "Mechatronics",
    "Science and humanity",
    "Workshop",
    "Applied Mechanics",
    "Other Dept"
  ];

  Future<void> addData(String name, int no, String vehno, String branch) async {
    if (phoneNumber.isEmpty) {
      log("Phone number is required");
      return;
    }

    await FirebaseFirestore.instance.collection("Users").doc(widget.email).update({
      "Name": name,
      "Id": no,
      "Vehicle no": vehno,
      "Branch": branch,
      "Phone": phoneNumber,
      "email": widget.email,
    }).then((value) {
      log("Data inserted");
    });

    await FirebaseFirestore.instance.collection("HOD").doc(widget.email).update({
      "Name": name,
      "Id": no,
      "Vehicle no": vehno,
      "Branch": branch,
      "Phone": phoneNumber,
      "email": widget.email,
    }).then((value) {
      log("Data inserted");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tell us a bit about yourself!"),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: SingleChildScrollView(
          child: Container(
            constraints: BoxConstraints(maxWidth: 600),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [


                  Text(
                    "Enter your details",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: TextFormField(
                      controller: nametc,
                      decoration: InputDecoration(
                        hintText: "Enter your name",
                        suffixIcon: Icon(Icons.person),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Name is required';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: TextFormField(
                      controller: rolltc,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        hintText: "Enter your ID number",
                        suffixIcon: Icon(Icons.numbers),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty || int.tryParse(value) == null) {
                          return 'Valid ID number is required';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: IntlPhoneField(
                      decoration: InputDecoration(
                        hintText: "Enter your phone number",
                        suffixIcon: Icon(Icons.phone),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      initialCountryCode: 'IN',
                      onChanged: (phone) {
                        phoneNumber = phone.completeNumber;
                      },
                      validator: (phone) {
                        if (phone == null || phone.completeNumber.isEmpty) {
                          return 'Phone number is required';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: TextFormField(
                      controller: vehtc,
                      decoration: InputDecoration(
                        hintText: "Enter your vehicle number (Optional)",
                        suffixIcon: Icon(Icons.directions_car),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: DropdownButtonFormField<String>(
                      value: selectedBranch,
                      decoration: InputDecoration(
                        hintText: "Select HOD's branch",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      items: branches.map((String branch) {
                        return DropdownMenuItem<String>(
                          value: branch,
                          child: Text(branch),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedBranch = newValue;
                        });
                      },
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Branch selection is required';
                        }
                        return null;
                      },
                    ),
                  ),
                  SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: () {
                      if (phoneNumber.isEmpty) {
                        // Show dialog if phone number is required
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text("Phone Number Required"),
                              content: Text("Please enter your phone number before submitting."),
                              actions: [
                                TextButton(
                                  child: Text("OK"),
                                  onPressed: () {
                                    Navigator.of(context).pop(); // Close the dialog
                                  },
                                ),
                              ],
                            );
                          },
                        );
                      } else if (_formKey.currentState!.validate()) {
                        addData(
                          nametc.text,
                          int.tryParse(rolltc.text) ?? 0,
                          vehtc.text,
                          selectedBranch ?? "",
                        );
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => RootPage3(email: widget.email),
                          ),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      padding: EdgeInsets.symmetric(
                        horizontal: 50,
                        vertical: 15,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Text(
                      "Submit",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}