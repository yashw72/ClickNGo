import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';
import 'package:lottie/lottie.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart'; // Package to open files
import 'package:google_mobile_ads/google_mobile_ads.dart';
class HODBoundaryBreachesPage extends StatefulWidget {
  final String hodEmail;

  const HODBoundaryBreachesPage({Key? key, required this.hodEmail}) : super(key: key);

  @override
  State<HODBoundaryBreachesPage> createState() => _HODBoundaryBreachesPageState();
}

class _HODBoundaryBreachesPageState extends State<HODBoundaryBreachesPage> {
  RewardedInterstitialAd? _rewardedInterstitialAd;
  bool _isAdLoaded = false;

  late Stream<QuerySnapshot> _breachesStream;
  bool _showAnimation = true;
  String branch = "";
  String hodName = "";
  int hodid=0;
  @override
  void initState() {
    super.initState();
    _fetchBranchForHOD();
    _loadBreachesAfterDelay();
    _loadRewardedInterstitialAd();
  }
  void _loadRewardedInterstitialAd() {
    RewardedInterstitialAd.load(
      adUnitId: 'ca-app-pub-5214491851748744/3861076815',  // Replace with your actual Ad Unit ID
      request: AdRequest(),
      rewardedInterstitialAdLoadCallback: RewardedInterstitialAdLoadCallback(
        onAdLoaded: (RewardedInterstitialAd ad) {
          print('Rewarded Interstitial Ad loaded.');
          setState(() {
            _rewardedInterstitialAd = ad;
            _isAdLoaded = true;
          });

        },
        onAdFailedToLoad: (LoadAdError error) {
          print('Rewarded Interstitial Ad failed to load: $error');
          setState(() {
            _isAdLoaded = false;
          });
        },
      ),
    );
  }

  Future<void> _showRewardedInterstitialAd(List<QueryDocumentSnapshot> breachesDocs)async {
    if (_isAdLoaded && _rewardedInterstitialAd != null) {
      _rewardedInterstitialAd!.show(

        onUserEarnedReward: (AdWithoutView ad, RewardItem reward) async {
          print('User earned reward: ${reward.amount} ${reward.type}');
            _generateAndOpenPDF(breachesDocs);
        },
      ).then((value) async {
        // This block runs after the ad is fully closed.
        print('Ad completed, generating PDF...');
        _generateAndOpenPDF(breachesDocs);
      }).catchError((error) async {
        print('Error showing ad: $error');
        // If there's an error while showing the ad, generate the PDF anyway.
         _generateAndOpenPDF(breachesDocs);
      }).whenComplete(() async {
        _rewardedInterstitialAd?.dispose();
        _loadRewardedInterstitialAd();  // Load the next ad

      });

    } else {
      print('Rewarded Interstitial Ad is not ready to be shown.');
       _generateAndOpenPDF(breachesDocs);  // If ad is not ready, generate PDF immediately
      _loadRewardedInterstitialAd();
    }

  }


  Future<void> _fetchBranchForHOD() async {
    try {
      DocumentReference hodDoc = FirebaseFirestore.instance.collection('Users').doc(widget.hodEmail);
      DocumentSnapshot userDoc = await hodDoc.get();

      if (userDoc.exists) {
        setState(() {
          branch = userDoc['Branch'] ?? "";
          hodName = userDoc['Name'] ?? "";
          hodid = userDoc['Id'] ?? 0;
        });

        _breachesStream = FirebaseFirestore.instance
            .collection('HOD')
            .doc(widget.hodEmail)
            .collection('BREACHES')
            .orderBy('timeCrossed', descending: true)
            .snapshots();
      } else {
        print('HOD email not found');
      }
    } catch (e) {
      print('Error fetching branch: $e');
    }
  }

  Future<void> _loadBreachesAfterDelay() async {
    await Future.delayed(Duration(seconds: 3));
    if (mounted) {
      setState(() {
        _showAnimation = false;
      });
    }
  }

  Map<String, List<QueryDocumentSnapshot>> _groupByDate(List<QueryDocumentSnapshot> docs) {
    Map<String, List<QueryDocumentSnapshot>> groupedData = {};

    for (var doc in docs) {
      final data = doc.data() as Map<String, dynamic>;
      final dateCrossed = data['dateCrossed'] ?? 'Unknown Date';

      if (!groupedData.containsKey(dateCrossed)) {
        groupedData[dateCrossed] = [];
      }

      groupedData[dateCrossed]!.add(doc);
    }

    return groupedData;
  }

  String _getFormattedDate(DateTime date) {
    return DateFormat('yyyy-MM-dd').format(date);
  }

  @override
  Widget build(BuildContext context) {
    final today = _getFormattedDate(DateTime.now());
    final yesterday = _getFormattedDate(DateTime.now().subtract(Duration(days: 1)));

    return Scaffold(
      body: _showAnimation
          ? Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Lottie.asset(
                'assets/animations/Animation - 1725686193709.json',
                width: 270,
                height: 200,
              ),
              const Text(
                'Fetching Boundary Breaches',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      )
          : StreamBuilder<QuerySnapshot>(
        stream: _breachesStream,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error fetching breaches: ${snapshot.error}',
                style: TextStyle(color: Colors.red, fontSize: 16),
              ),
            );
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text(
                'No boundary breaches found.',
                style: TextStyle(color: Colors.black54, fontSize: 16),
              ),
            );
          }

          final breachesDocs = snapshot.data!.docs;
          final groupedData = _groupByDate(breachesDocs);

          List<String> sortedKeys = groupedData.keys.toList()
            ..sort((a, b) => b.compareTo(a));

          return ListView(
            padding: const EdgeInsets.all(16.0),
            children: sortedKeys.map((date) {
              final breachesForDate = groupedData[date] ?? [];

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Date: $date',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  SizedBox(height: 8),
                  ...breachesForDate.map((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    return Container(
                      width: MediaQuery.of(context).size.width * 0.9,
                      margin: const EdgeInsets.only(bottom: 16.0),
                      padding: const EdgeInsets.all(16.0),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            spreadRadius: 1,
                            blurRadius: 8,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Faculty Name: ${data['facultyName']}',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.black87,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            'Time Crossed: ${data['timeCrossed']}',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.black54,
                            ),
                          ),
                          SizedBox(height: 4),
                        ],
                      ),
                    );
                  }).toList(),
                  SizedBox(height: 16),
                ],
              );
            }).toList(),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final snapshot = await FirebaseFirestore.instance
              .collection('HOD')
              .doc(widget.hodEmail)
              .collection('BREACHES')
              .orderBy('timeCrossed', descending: true)
              .get();

          if (snapshot.docs.isNotEmpty) {
            await _showRewardedInterstitialAd(snapshot.docs);

          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('No breaches data to download.')),
            );
          }
        },
        child: Icon(Icons.download),
        tooltip: 'Download PDF',
      ),
    );
  }
  Future<void> _generateAndOpenPDF(List<QueryDocumentSnapshot> breachesDocs) async {
    try {
      final pdf = pw.Document();

      if (breachesDocs.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No breaches data to generate PDF.')),
        );
        return;
      }

      final groupedData = _groupByDate(breachesDocs);
      List<String> sortedKeys = groupedData.keys.toList()..sort((a, b) => b.compareTo(a));

      // Load the college logo
      final ByteData data = await rootBundle.load('assets/images/gpnlogo.jpg');
      final Uint8List logoImage = data.buffer.asUint8List();

      pdf.addPage(
        pw.MultiPage(
          build: (pw.Context context) {
            return [
              // Header with College and HOD Details
              pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.Image(
                    pw.MemoryImage(logoImage),
                    width: 100,
                    height: 100,
                  ),
                  pw.SizedBox(width: 16),
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(
                        'Government Polytechnic Nashik',
                        style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      pw.Text(
                        'Head of the department: $hodName',
                        style: pw.TextStyle(
                          fontSize: 16,
                        ),
                      ),
                      pw.Text(
                        'Head of the department ID: $hodid',
                        style: pw.TextStyle(
                          fontSize: 16,
                        ),
                      ),
                      pw.Text(
                        'Branch: $branch',
                        style: pw.TextStyle(
                          fontSize: 16,
                        ),
                      ),
                      pw.Text(
                        'Head of Department email: ${widget.hodEmail}',
                        style: pw.TextStyle(
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              pw.SizedBox(height: 16),
              pw.Text(
                'Faculty Boundary Breaches Report',
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 24,
                ),
              ),
              pw.SizedBox(height: 6),
              pw.Divider(height: 20),
              pw.SizedBox(height: 10),
              // Data Table
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: sortedKeys.map((date) {
                  final breachesForDate = groupedData[date] ?? [];

                  return [
                    pw.Text(
                      'Date: $date',
                      style: pw.TextStyle(
                        fontWeight: pw.FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    pw.SizedBox(height: 8),
                    pw.Table(
                      border: pw.TableBorder.all(),
                      columnWidths: {
                        0: pw.IntrinsicColumnWidth(),
                        1: pw.IntrinsicColumnWidth(),
                        2: pw.IntrinsicColumnWidth(),
                      },
                      children: [
                        pw.TableRow(
                          children: [
                            pw.Padding(
                              padding: pw.EdgeInsets.all(8.0),
                              child: pw.Text('Faculty Name', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                            ),
                            pw.Padding(
                              padding: pw.EdgeInsets.all(8.0),
                              child: pw.Text('Date Crossed', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                            ),
                            pw.Padding(
                              padding: pw.EdgeInsets.all(8.0),
                              child: pw.Text('Time Crossed', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                            ),
                          ],
                        ),
                        ...breachesForDate.map(
                              (doc) {
                            final data = doc.data() as Map<String, dynamic>;
                            return pw.TableRow(
                              children: [
                                pw.Padding(
                                  padding: pw.EdgeInsets.all(8.0),
                                  child: pw.Text(data['facultyName'] ?? 'N/A'),
                                ),
                                pw.Padding(
                                  padding: pw.EdgeInsets.all(8.0),
                                  child: pw.Text(data['dateCrossed'] ?? 'N/A'),
                                ),
                                pw.Padding(
                                  padding: pw.EdgeInsets.all(8.0),
                                  child: pw.Text(data['timeCrossed'] ?? 'N/A'),
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ),
                    pw.SizedBox(height: 16),
                  ];
                }).expand((e) => e).toList(), // Flatten the list of lists
              ),
            ];
          },
        ),
      );

      // Save the PDF and open it for the user
      final output = await getTemporaryDirectory();
      final file = File("${output.path}/boundary_breaches_report.pdf");
      await file.writeAsBytes(await pdf.save());
      print("PDF Saved: ${file.path}");

      // Open the saved PDF file
      OpenFile.open(file.path);
    } catch (e) {
      print("Error generating or opening PDF: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error generating PDF.')),
      );
    }
  }



}
