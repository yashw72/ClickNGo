import 'package:clickngo/HOD/HODRegisterScreen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../FACULTY/root2.dart';
import 'root3.dart';
import '../FACULTY/FacultyRegisterScreen.dart';
import 'HODLoginScreen.dart';

class HODLoginScreen extends StatefulWidget {
  const HODLoginScreen({Key? key}) : super(key: key);

  @override
  _HODLoginScreenState createState() => _HODLoginScreenState();
}

class _HODLoginScreenState extends State<HODLoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  String _errorMessage = '';
  bool _isPasswordVisible = false; // Manage password visibility
  FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;

  Future<void> storeUserDetails(User user, String role) async {
    // Storing details in Firestore using the user's existing UID
    FirebaseFirestore.instance.collection('loggedUsers').doc(user.uid).set({
      'email': user.email,
      'role': role,
    });

    // Storing details locally using shared_preferences
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('email', user.email!);
    await prefs.setString('role', role);
  }

  Future<void> _loginHOD() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
        _errorMessage = '';
      });

      try {
        UserCredential userCredential =
            await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        User? user = userCredential.user;

        if (user != null) {
          // Call storeUserDetails after successful login
          await storeUserDetails(user, 'HOD'); // Pass the role as 'HOD'

          // Generate device token and submit it to Firestore
          await _generateAndSubmitDeviceToken(userCredential.user!);
          // HOD Login check
          if (user.email == 'hod@example.com') {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    RootPage3(email: user.email!), // Navigate to HOD page
              ),
            );
          } else {
            // Navigate to Faculty home page
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    RootPage3(email: user.email!), // Faculty home page
              ),
            );
          }
        }
      } catch (e) {
        setState(() {
          _errorMessage = e.toString();
        });
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _generateAndSubmitDeviceToken(User user) async {
    String? deviceToken = await _firebaseMessaging.getToken();

    if (deviceToken != null) {
      await FirebaseFirestore.instance
          .collection('HOD')
          .doc(user.email)
          .update({
        'deviceToken': deviceToken,
      });
      print("Device Token submitted to Firestore: $deviceToken");
    } else {
      print("Failed to get device token.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "HOD Login",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 35),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          labelText: "Email Address",
                          hintText: "Enter HOD Email",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your email';
                          }
                          if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                            return 'Please enter a valid email address';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 20),
                      TextFormField(
                        controller: _passwordController,
                        obscureText: !_isPasswordVisible,
                        decoration: InputDecoration(
                          labelText: "Password",
                          hintText: "Enter your Password",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _isPasswordVisible
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                              color: Colors.grey,
                            ),
                            onPressed: () {
                              setState(() {
                                _isPasswordVisible = !_isPasswordVisible;
                              });
                            },
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your password';
                          }
                          if (value.length < 6) {
                            return 'Password must be at least 6 characters long';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 20),
                      _isLoading
                          ? CircularProgressIndicator()
                          : ElevatedButton(
                              onPressed: _loginHOD,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.black,
                                padding: EdgeInsets.symmetric(
                                  horizontal: 100,
                                  vertical: 15,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: Text(
                                "Login",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                      SizedBox(height: 20),
                      if (_errorMessage.isNotEmpty)
                        Text(
                          _errorMessage,
                          style: TextStyle(color: Colors.red),
                          textAlign: TextAlign.center,
                        ),
                      SizedBox(height: 15),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => HODRegister()),
                          );
                        },
                        child: Text("Don't have an account? Sign Up"),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
