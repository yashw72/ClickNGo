import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool _isEditing = false;
  bool _isLoading = true;
  bool _isSaveSuccessful = false;
  bool _hasError = false;

  TextEditingController _nameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _idController = TextEditingController();
  TextEditingController _phoneController = TextEditingController(); // Phone number for all roles
  TextEditingController _vehicleNoController = TextEditingController();
  TextEditingController _roleController = TextEditingController(); // New controller for role

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String? _userRole; // Field to store the role

  @override
  void initState() {
    super.initState();
    _fetchUserProfile();
  }

  Future<void> _fetchUserProfile() async {
    User? user = _auth.currentUser;

    if (user != null) {
      try {
        DocumentSnapshot userDoc = await _firestore.collection('Users').doc(user.email).get();

        if (userDoc.exists) {
          setState(() {
            _nameController.text = userDoc['Name'] ?? '';
            _emailController.text = userDoc['email'] ?? '';
            _userRole = userDoc['Role']; // Fetch the role
            _roleController.text = _userRole ?? ''; // Set role in the new controller
            _phoneController.text = userDoc['Phone'] ?? ''; // Always fetch phone number

            // Handle ID and Vehicle No based on user role
            if (_userRole == 'Student' || _userRole == 'Employee') {
              _idController.text = userDoc['Id']?.toString() ?? '';
            }

            // Fetch Vehicle No for all roles including Delivery Person
            if (userDoc['Vehicle no'] != null) {
              _vehicleNoController.text = userDoc['Vehicle no'] ?? '';
            }

            _isLoading = false;
          });
        } else {
          print("Document does not exist");
          setState(() {
            _isLoading = false;
          });
        }
      } catch (e) {
        print("Error fetching document: $e");
        setState(() {
          _isLoading = false;
          _hasError = true;
        });
      }
    }
  }

  Future<void> _saveUserProfile() async {
    User? user = _auth.currentUser;

    if (user != null) {
      setState(() {
        _isLoading = true;
        _isSaveSuccessful = false;
        _hasError = false;
      });

      try {
        Map<String, dynamic> updateData = {
          'Name': _nameController.text,
          'email': _emailController.text,
          'Role': _roleController.text, // Include the role
          'Phone': _phoneController.text, // Always include phone number
        };

        // Add ID only if the role is Student or Employee
        if (_roleController.text == 'Student' || _roleController.text == 'Employee') {
          updateData['Id'] = _idController.text;
        }

        // Always include Vehicle No for all roles
        if (_vehicleNoController.text.isNotEmpty) {
          updateData['Vehicle no'] = _vehicleNoController.text;
        }

        await _firestore.collection('Users').doc(user.email).update(updateData);

        setState(() {
          _isEditing = false;
          _isSaveSuccessful = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Profile updated successfully!')),
        );
      } catch (e) {
        print("Error updating document: $e");
        setState(() {
          _isSaveSuccessful = false;
          _hasError = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving profile.')),
        );
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        actions: [
          IconButton(
            icon: Icon(_isEditing ? Icons.check : Icons.edit),
            onPressed: () {
              if (_isEditing) {
                _saveUserProfile();
              } else {
                setState(() {
                  _isEditing = true;
                });
              }
            },
          ),
        ],
      ),
      body: Center(
        child: _isLoading
            ? CircularProgressIndicator()
            : SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              CircleAvatar(
                backgroundColor: Colors.white,
                radius: 100.0,
                backgroundImage: AssetImage('assets/images/Sample_User_Icon.png'),
              ),
              SizedBox(height: 20.0),
              _buildTextField(
                controller: _roleController,
                label: 'Role',
                icon: Icons.badge,
                enabled: false, // Make role field non-editable
              ),
              _buildTextField(
                controller: _nameController,
                label: 'Name',
                icon: Icons.person,
                enabled: _isEditing, // Enable/disable based on editing mode
              ),
              _buildTextField(
                controller: _emailController,
                label: 'Email',
                icon: Icons.email,
                enabled: _isEditing, // Enable/disable based on editing mode
              ),
              _buildTextField(
                controller: _phoneController,
                label: 'Phone',
                icon: Icons.phone, // Phone number field
                enabled: _isEditing, // Enable/disable based on editing mode
              ),
              if (_userRole == 'Student' || _userRole == 'Employee')
                _buildTextField(
                  controller: _idController,
                  label: 'ID',
                  icon: Icons.perm_identity,
                  enabled: _isEditing, // Enable/disable based on editing mode
                ),
              // Display Vehicle No field for all roles including Delivery Person
              _buildTextField(
                controller: _vehicleNoController,
                label: 'Vehicle No',
                icon: Icons.directions_car,
                enabled: _isEditing, // Enable/disable based on editing mode
              ),
              if (_isEditing)
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ElevatedButton(
                    onPressed: _saveUserProfile,
                    child: Text('Save'),
                  ),
                ),
              if (_isSaveSuccessful)
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Profile updated successfully!',
                    style: TextStyle(color: Colors.green),
                  ),
                ),
              if (_hasError && !_isLoading && !_isEditing)
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Error occurred while saving.',
                    style: TextStyle(color: Colors.red),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool enabled = true, // Add an enabled parameter
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(),
        ),
        enabled: enabled, // Use the enabled parameter
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _idController.dispose();
    _phoneController.dispose();
    _vehicleNoController.dispose();
    _roleController.dispose(); // Dispose the new controller
    super.dispose();
  }
}